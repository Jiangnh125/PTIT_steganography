import cv2
import numpy as np

def extract_dct_coeffs(frame_path, coeff_position=(4, 4)):
    """Trích xuất hệ số DCT tại vị trí chỉ định từ khung hình."""
    frame = cv2.imread(frame_path, cv2.IMREAD_GRAYSCALE)
    if frame is None:
        print(f"[-] Không đọc được {frame_path}")
        return []

    height, width = frame.shape
    block_size = 8
    coeffs = []

    for i in range(0, height, block_size):
        for j in range(0, width, block_size):
            block = frame[i:i+block_size, j:j+block_size]
            if block.shape != (8, 8):  # Bỏ qua các khối không đầy đủ
                continue
            dct = cv2.dct(np.float32(block))
            coeffs.append(dct[coeff_position])
    
    return coeffs

def compare_statistics(coeffs1, coeffs2, label1='Gốc', label2='Giấu tin'):
    """So sánh thống kê giữa hai tập hệ số DCT."""
    if not coeffs1 or not coeffs2:
        print("[-] Không có dữ liệu để so sánh.")
        return

    stats1 = {
        "mean": np.mean(coeffs1),
        "std": np.std(coeffs1),
        "min": np.min(coeffs1),
        "max": np.max(coeffs1)
    }

    stats2 = {
        "mean": np.mean(coeffs2),
        "std": np.std(coeffs2),
        "min": np.min(coeffs2),
        "max": np.max(coeffs2)
    }

    print(f"\nSo sánh thống kê hệ số DCT tại vị trí (4,4):")
    print(f"{label1}:")
    print(f"  - Trung bình: {stats1['mean']:.2f}")
    print(f"  - Độ lệch chuẩn: {stats1['std']:.2f}")
    print(f"  - Giá trị nhỏ nhất: {stats1['min']:.2f}")
    print(f"  - Giá trị lớn nhất: {stats1['max']:.2f}")
    print(f"{label2}:")
    print(f"  - Trung bình: {stats2['mean']:.2f}")
    print(f"  - Độ lệch chuẩn: {stats2['std']:.2f}")
    print(f"  - Giá trị nhỏ nhất: {stats2['min']:.2f}")
    print(f"  - Giá trị lớn nhất: {stats2['max']:.2f}")

def main():
    # Trích xuất hệ số DCT từ khung hình đã lưu
    print("[+] Phân tích hệ số DCT...")
    coeffs_clean = extract_dct_coeffs("clean_frame.png")
    coeffs_stego = extract_dct_coeffs("stego_frame.png")

    # So sánh thống kê
    compare_statistics(coeffs_clean, coeffs_stego, label1="Gốc", label2="Giấu tin")

if __name__ == "__main__":
    main()

