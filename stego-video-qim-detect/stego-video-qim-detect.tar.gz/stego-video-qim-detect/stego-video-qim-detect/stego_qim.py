import cv2
import numpy as np
import os
import subprocess

DELTA = 10.0

def embed_qim(coeff, bit, delta):
    q = np.round(coeff / delta)
    return q * delta if bit == 0 else (q + 0.5) * delta

def string_to_bits(s):
    return ''.join(format(len(s), '016b') + ''.join(format(ord(c), '08b') for c in s))

def hide_message_in_frame(frame_gray, message_bits, delta=DELTA):
    h, w = frame_gray.shape
    block_size = 8
    bit_idx = 0
    modified = frame_gray.copy()

    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            if bit_idx >= len(message_bits):
                break
            block = frame_gray[i:i+block_size, j:j+block_size]
            if block.shape[0] < block_size or block.shape[1] < block_size:
                continue
            dct = cv2.dct(np.float32(block))
            dct[4, 4] = embed_qim(dct[4, 4], int(message_bits[bit_idx]), delta)
            idct = cv2.idct(dct)
            modified[i:i+block_size, j:j+block_size] = np.clip(idct, 0, 255)
            bit_idx += 1
    return modified

def main():
    input_video = "input_video.mpg"
    message_file = "message.txt"
    os.makedirs("temp", exist_ok=True)
    os.makedirs("output", exist_ok=True)

    # 1. Trích xuất khung I
    print("[+] Trích xuất khung I...")
    subprocess.run("ffmpeg -y -i input_video.mpg -vf select='eq(pict_type\\,I)' -vsync vfr temp/frame%04d.png", shell=True)
    print("[✓] Đã trích xuất khung I")

   
    message = "Day la tin bi mat"
    bits = string_to_bits(message)

    # 3. Giấu tin vào frame0001
    print("[+] Giấu tin vào frame0001.png...")
    frame = cv2.imread("temp/frame0001.png", cv2.IMREAD_GRAYSCALE)
    modified = hide_message_in_frame(frame, bits)
    cv2.imwrite("output/frame0001.png", modified, [cv2.IMWRITE_PNG_COMPRESSION, 0])

    # 4. Copy các frame còn lại
    idx = 2
    while True:
        src = f"temp/frame{idx:04d}.png"
        dst = f"output/frame{idx:04d}.png"
        if not os.path.exists(src):
            break
        frame = cv2.imread(src, cv2.IMREAD_GRAYSCALE)
        cv2.imwrite(dst, frame, [cv2.IMWRITE_PNG_COMPRESSION, 0])
        idx += 1

    # 5. Kết hợp lại thành video MPEG-2
    print("[+] Tạo video đã giấu tin...")
    subprocess.run("ffmpeg -y -framerate 23.98 -i output/frame%04d.png -c:v mpeg2video -q:v 1 output_video.mpg", shell=True)
    print("[✓] Hoàn tất: output_video.mpg")

if __name__ == "__main__":
    main()

