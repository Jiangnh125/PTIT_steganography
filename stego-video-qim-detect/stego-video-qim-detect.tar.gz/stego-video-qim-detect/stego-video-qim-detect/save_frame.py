import subprocess

def save_first_frame(video_path, output_frame):
    """Lưu khung hình đầu tiên của video."""
    cmd = f"ffmpeg -y -i {video_path} -vf select='eq(n\,0)' -vsync vfr {output_frame}"
    subprocess.run(cmd, shell=True)
    print(f"[✓] Đã lưu khung hình đầu tiên từ {video_path} vào {output_frame}")

def main():
    video_clean = "input_video.mpg"  # Video gốc chưa giấu tin
    video_stego = "output_video.mpg"  # Video đã giấu tin

    # Lưu khung hình đầu tiên từ mỗi video
    save_first_frame(video_clean, "clean_frame.png")
    save_first_frame(video_stego, "stego_frame.png")

if __name__ == "__main__":
    main()

