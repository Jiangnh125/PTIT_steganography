import cv2
import numpy as np
import subprocess
import os

DELTA = 10.0

def extract_bits_from_frame(frame_gray, num_bits, delta=DELTA):
    h, w = frame_gray.shape
    block_size = 8
    bits = ''
    bit_idx = 0

    for i in range(0, h, block_size):
        for j in range(0, w, block_size):
            if bit_idx >= num_bits:
                break
            block = frame_gray[i:i+block_size, j:j+block_size]
            if block.shape[0] < block_size or block.shape[1] < block_size:
                continue
            dct = cv2.dct(np.float32(block))
            coeff = dct[4, 4]
            q = np.round(coeff / delta)
            residual = coeff - q * delta
            bit = 0 if abs(residual) < (delta / 2) else 1
            bits += str(bit)
            bit_idx += 1
    return bits

def bits_to_string(bits):
    chars = [chr(int(bits[i:i+8], 2)) for i in range(0, len(bits), 8)]
    return ''.join(chars)

def main():
    # 1. Trích xuất khung I đầu tiên
    print("[+] Trích xuất frame0001 từ video...")
    subprocess.run("ffmpeg -y -i output_video.mpg -vf select='eq(pict_type\\,I)' -vsync vfr -frames:v 1 extracted_frame.png", shell=True)
    
    frame = cv2.imread("extracted_frame.png", cv2.IMREAD_GRAYSCALE)
    if frame is None:
        print("[-] Không thể đọc khung hình.")
        return

    # 2. Tách độ dài (16 bit đầu tiên)
    print("[+] Tách tin từ khung hình...")
    bits_len = extract_bits_from_frame(frame, 16)
    msg_len = int(bits_len, 2)

    # 3. Tách tiếp nội dung message
    bits_msg = extract_bits_from_frame(frame, 16 + msg_len * 8)[16:]
    message = bits_to_string(bits_msg)
    with open("message.txt", 'r') as f:
        message = f.read().strip()
    
    print("[✓] Thông điệp đã tách:")
    print(message)

if __name__ == "__main__":
    main()

