#!/bin/bash
mkdir -p temp
ffmpeg -i input_video.mpg -vf select='eq(pict_type\,I)' -vsync vfr temp/frame%04d.png
echo "[✓] Đã trích xuất khung I vào temp"

