import cv2
import numpy as np
import os
import subprocess

def embed_qim(dct_coeff, bit, delta):
    q = np.round(dct_coeff / delta)
    return q * delta if bit == 0 else (q + 0.5) * delta

def string_to_bits(s):
    return ''.join(format(ord(c), '08b') for c in s)

def hide_message_in_frame(frame_gray, message, delta=10.0):
    height, width = frame_gray.shape
    block_size = 8
    bits = string_to_bits(message)
    bit_idx = 0
    modified = frame_gray.copy()

    for i in range(0, height, block_size):
        for j in range(0, width, block_size):
            if bit_idx >= len(bits):
                break
            block = frame_gray[i:i+block_size, j:j+block_size]
            dct = cv2.dct(np.float32(block))
            dct[4, 4] = embed_qim(dct[4, 4], int(bits[bit_idx]), delta)
            idct = cv2.idct(dct)
            modified[i:i+block_size, j:j+block_size] = np.clip(idct, 0, 255)
            bit_idx += 1
    return modified

def main():
    message_path = "message.txt"
    input_pattern = "temp/frame%04d.png"
    output_dir = "modified_frames"

    if not os.path.exists(message_path):
        print("[-] Không tìm thấy message.txt")
        return

    with open(message_path, "r") as f:
        message = f.read().strip()

    if not os.path.exists(output_dir):
        os.makedirs(output_dir)

    idx = 1
    while True:
        input_file = f"temp/frame{idx:04d}.png"
        output_file = f"{output_dir}/frame{idx:04d}.png"
        if not os.path.exists(input_file):
            break

        print(f"[+] Xử lý {input_file}...")

        frame = cv2.imread(input_file, cv2.IMREAD_GRAYSCALE)
        if frame is None:
            print(f"[-] Lỗi khi đọc {input_file}")
            break

        if idx == 1:
            print("[+] Giấu tin vào khung I đầu tiên...")
            frame = hide_message_in_frame(frame, message)

        cv2.imwrite(output_file, frame.astype(np.uint8))
        idx += 1

    print("[+] Tạo lại video MPEG-2 từ các khung hình...")
    cmd = f"ffmpeg -y -framerate 23.98 -i {output_dir}/frame%04d.png -c:v mpeg2video -q:v 2 output_video.mpg"
    subprocess.run(cmd, shell=True)

    print("[✓] Hoàn tất. Video đã giấu tin: output_video.mpg")

if __name__ == "__main__":
    main()

